netbeans 13

install jdekstop layout plugin ke netbeans
install i-report plugin ke netbeans

buat database tugas

import tugas.sql